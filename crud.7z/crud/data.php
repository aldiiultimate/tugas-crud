<?php

?>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Informasi Mahasiswa</title>
</head>

<body>
    <nav style="height:auto; background-color: black;">
        <h1 style="color: white;">Sistem Informasi Mahasiswa</h1>
        <table>
            <td><a href="index.php" style="color: white;">Home</a></td>
            <td><a href="#" style="color: white;">Data</a></td>
            <td><a href="admin.php" style="color: white;">Admin</a></td>
        </table>
    </nav>

    <h2>List Mahasiswa</h2>
    <table border="1">
        <tr>
            <th>NO</th>
            <th>NIM</th>
            <th>NAMA</th>
            <th>GENDER</th>
            <th>JURUSAN</th>
        </tr>
        <?php
        include 'koneksi.php';
        $mahasiswa = mysqli_query($koneksi, "SELECT * from mahasiswa");
        $no = 1;
        foreach ($mahasiswa as $row) {
            $jenis_kelamin = $row['jenis_kelamin'] == 'P' ? 'Perempuan' : 'Laki laki';
            echo "<tr>
        <td>$no</td>
        <td>" . $row['nim'] . "</td>
        <td>" . $row['nama'] . "</td>
        <td>" . $jenis_kelamin, "</td>
        <td>" . $row['jurusan'], "</td>
        </tr>";
            $no++;
        }
        ?>
    </table>
</body>

</html>