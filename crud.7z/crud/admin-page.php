<?php

?>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Informasi Mahasiswa</title>
</head>

<body>
    <nav style="height:auto; background-color: black;">
        <h1 style="color: white;">Sistem Informasi Mahasiswa</h1>
        <table>
            <td><a href="index.php" style="color: white;">Home</a></td>
            <td><a href="data.php" style="color: white;">Data</a></td>
            <td><a href="admin.php" style="color: white;">Admin</a></td>
        </table>
    </nav>

    <h2>List Mahasiswa</h2>
    <table border="1">
        <tr>
            <th>NO</th>
            <th>NIM</th>
            <th>NAMA</th>
            <th>GENDER</th>
            <th>JURUSAN</th>
            <th>ACTION</th>
        </tr>
        <?php
        include 'koneksi.php';
        $mahasiswa = mysqli_query($koneksi, "SELECT * from mahasiswa");
        $no = 1;
        foreach ($mahasiswa as $row) {
            $jenis_kelamin = $row['jenis_kelamin'] == 'P' ? 'Perempuan' : 'Laki laki';
            echo "<tr>
        <td>$no</td>
        <td>" . $row['nim'] . "</td>
        <td>" . $row['nama'] . "</td>
        <td>" . $jenis_kelamin, "</td>
        <td>" . $row['jurusan'], "</td>
        <td><a href='form-edit.php?id_mhs=$row[id_mhs]'>edit</a>
        <a href='delete.php?id_mhs=$row[id_mhs]'>delet</a>
        </tr>";
            $no++;
        }
        ?>
    </table>
    <h2>List Dosen</h2>
    <table border="1">
        <tr>
            <th>NO</th>
            <th>NIP</th>
            <th>NAMA</th>
            <th>MATA KULIAH</th>
            <th>ACTION</th>
        </tr>
        <?php
        include 'koneksi.php';
        $dosen = mysqli_query($koneksi, "SELECT dosen.id_dosen,dosen.nama, dosen.nip, matkul.matkul FROM `dosen` INNER JOIN matkul ON dosen.matkul = matkul.id_matkul ");
        $no = 1;
        foreach ($dosen as $row) {
            // $jenis_kelamin = $row['jenis_kelamin'] == 'P' ? 'Perempuan' : 'Laki laki';
            echo "<tr>
        <td>$no</td>
        <td>" . $row['nip'] . "</td>
        <td>" . $row['nama'] . "</td>
        <td>" . $row['matkul'], "</td>
        <td><a href='edit-form-dosen.php?id_dosen=$row[id_dosen]' class='btn btn-warning'>edit</a>
        <a href='delete-dosen.php?id_dosen=$row[id_dosen]' class='btn btn-danger'>delete</a>
        </tr>";
            $no++;
        }
        ?>
    </table>
    <a href="dosen.php">add dosen</a>
</body>

</html>