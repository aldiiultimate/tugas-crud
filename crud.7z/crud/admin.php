<?php

?>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Informasi Mahasiswa</title>
</head>

<body>
    <nav style="height:auto; background-color: black;">
        <h1 style="color: white;">Sistem Informasi Mahasiswa</h1>
        <table>
            <td><a href="index.php" style="color: white;">Home</a></td>
            <td><a href="#" style="color: white;">Data</a></td>
            <td><a href="#" style="color: white;">Admin</a></td>
        </table>
    </nav>

    <h1>Login</h1>
    <form action="login.php" method="post">
        <label for="username">Username:</label>
        <input type="text" id="nama" name="nama" required><br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br>
        <input type="submit" value="Login">
    </form>
</body>

</html>